package com.example.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DoctorLoginRequest {

    private String email;   // optional
    private String phone;   // optional
    private String password;
}

