package com.example.demo.service;

import com.example.demo.entity.Patient;

import java.util.List;

public interface PatientService {

    Patient registerPatient(Patient patient);

    List<Patient> getAllPatients();

    boolean loginPatient(String email, String phone, String password); // 👈 NEW
}
