package com.example.demo.controller;

import lombok.AllArgsConstructor;

import com.example.demo.entity.Doctor;
import com.example.demo.service.DoctorService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import com.example.demo.dto.DoctorLoginRequest;


import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/doctors")
public class DoctorController {

    private DoctorService doctorService;

    // Register doctor (already done)
    @PostMapping("/register")
    public ResponseEntity<Doctor> registerDoctor(@RequestBody Doctor doctor) {
        return new ResponseEntity<>(
                doctorService.registerDoctor(doctor),
                HttpStatus.CREATED
        );
    }

    // VIEW ALL DOCTORS
    @GetMapping
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        return ResponseEntity.ok(doctorService.getAllDoctors());
    }
    
    @PostMapping("/login")
    public ResponseEntity<Long> loginDoctor(@RequestBody DoctorLoginRequest request) {

        Long doctorId = doctorService.loginDoctorAndGetId(
                request.getEmail(),
                request.getPhone(),
                request.getPassword()
        );

        return ResponseEntity.ok(doctorId); // 👈 number or null
    }


    

}
