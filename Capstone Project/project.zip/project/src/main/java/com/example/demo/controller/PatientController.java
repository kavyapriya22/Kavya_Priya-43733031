package com.example.demo.controller;

import lombok.AllArgsConstructor;
import com.example.demo.dto.PatientLoginRequest;
import com.example.demo.entity.Patient;
import com.example.demo.service.PatientService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/patients")
public class PatientController {

    private PatientService patientService;

    @PostMapping("/register")
    public ResponseEntity<Patient> registerPatient(@RequestBody Patient patient) {
        return new ResponseEntity<>(
                patientService.registerPatient(patient),
                HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<List<Patient>> getAllPatients() {
        return ResponseEntity.ok(patientService.getAllPatients());
    }

    // PATIENT LOGIN API
    @PostMapping("/login")
    public ResponseEntity<Boolean> loginPatient(@RequestBody PatientLoginRequest request) {

        boolean isLoggedIn = patientService.loginPatient(
                request.getEmail(),
                request.getPhone(),
                request.getPassword()
        );

        return ResponseEntity.ok(isLoggedIn);
    }
}
