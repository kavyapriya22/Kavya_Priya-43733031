package com.example.demo.service.impl;

import lombok.AllArgsConstructor;
import com.example.demo.entity.Appointment;
import com.example.demo.entity.Patient;
import com.example.demo.repository.AppointmentRepository;
import com.example.demo.repository.PatientRepository;
import com.example.demo.service.AppointmentService;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Doctor;
import com.example.demo.repository.DoctorRepository;


import java.time.Duration;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class AppointmentServiceImpl implements AppointmentService {
	
	private DoctorRepository doctorRepository;
	

    private AppointmentRepository appointmentRepository;
    private PatientRepository patientRepository;

    @Override
    public boolean bookAppointment(Appointment appointment) {

        // 🔍 Step 1: Check time conflict (±15 minutes)
        List<Appointment> existingAppointments =
                appointmentRepository.findByDoctorIdAndAppointmentDate(
                        appointment.getDoctorId(),
                        appointment.getAppointmentDate()
                );

        for (Appointment existing : existingAppointments) {
            LocalTime existingTime = existing.getAppointmentTime();
            LocalTime requestedTime = appointment.getAppointmentTime();

            long minutesDiff = Math.abs(
                    Duration.between(existingTime, requestedTime).toMinutes()
            );

            if (minutesDiff < 15) {
                // ❌ Conflict found
                return false;
            }
        }

        // 🔍 Step 2: Attach patient info
        Optional<Patient> patientOptional = Optional.empty();

        if (appointment.getPatientEmail() != null) {
            patientOptional =
                    patientRepository.findByEmail(appointment.getPatientEmail());
        } else if (appointment.getPatientPhone() != null) {
            patientOptional =
                    patientRepository.findByPhone(appointment.getPatientPhone());
        }

        if (patientOptional.isPresent()) {
            Patient patient = patientOptional.get();
            appointment.setPatientId(patient.getId());
            appointment.setPatientPhone(patient.getPhone());
        }

        // ✅ Step 3: Save appointment
        appointmentRepository.save(appointment);
        return true;
    }

	@Override
	 public List<Appointment> getAppointmentsByPatient(String email, String phone) {

		List<Appointment> appointments;

	    if (email != null && !email.isEmpty()) {
	        appointments = appointmentRepository.findByPatientEmail(email);
	    } else {
	        appointments = appointmentRepository.findByPatientPhone(phone);
	    }

	    // 🔥 Attach doctor name
	    for (Appointment appointment : appointments) {
	        doctorRepository.findById(appointment.getDoctorId())
	                .ifPresent(doctor ->
	                        appointment.setDoctorName(doctor.getName()));
	    }

	    return appointments; // empty list if no input
    }
	
	@Override
	public List<Appointment> getAppointmentsForDoctor(Long doctorId) {

	    List<Appointment> appointments =
	            appointmentRepository.findByDoctorId(doctorId);

	    for (Appointment appointment : appointments) {
	        if (appointment.getPatientId() != null) {
	            patientRepository.findById(appointment.getPatientId())
	                    .ifPresent(patient ->
	                            appointment.setPatientName(patient.getName()));
	        }
	    }

	    return appointments;
	}
	
	@Override
	public void deleteAppointment(Long appointmentId) {
	    appointmentRepository.deleteById(appointmentId);
	}


	

}
