package com.example.demo.service.impl;

import lombok.AllArgsConstructor;
import com.example.demo.entity.Doctor;
import com.example.demo.repository.DoctorRepository;
import com.example.demo.service.DoctorService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class DoctorServiceImpl implements DoctorService {

    private DoctorRepository doctorRepository;

    @Override
    public Doctor registerDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }
    
    @Override
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();   // 👈 IMPORTANT
    }
    
    @Override
    public Long loginDoctorAndGetId(String email, String phone, String password) {
        Optional<Doctor> doctorOptional;

        if (email != null && !email.isEmpty()) {
            doctorOptional = doctorRepository.findByEmail(email);
        } else {
            doctorOptional = doctorRepository.findByPhone(phone);
        }

        if (doctorOptional.isPresent()) {
            Doctor doctor = doctorOptional.get();
            if (doctor.getPassword().equals(password)) {
                return doctor.getId();
            }
        }
        return null;
    }

    
    


}
