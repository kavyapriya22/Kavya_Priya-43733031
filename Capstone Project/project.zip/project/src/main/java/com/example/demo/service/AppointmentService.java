package com.example.demo.service;

import com.example.demo.entity.Appointment;

import java.util.List;

public interface AppointmentService {
	
	void deleteAppointment(Long appointmentId);

    boolean bookAppointment(Appointment appointment);

    List<Appointment> getAppointmentsByPatient(String email, String phone);
    
    List<Appointment> getAppointmentsForDoctor(Long doctorId);

   

}
