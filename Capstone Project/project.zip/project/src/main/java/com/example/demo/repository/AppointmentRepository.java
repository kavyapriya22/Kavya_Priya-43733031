package com.example.demo.repository;

import com.example.demo.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    // Find appointments for same doctor on same date
    List<Appointment> findByDoctorIdAndAppointmentDate(
            Long doctorId,
            LocalDate appointmentDate
    );
    
    List<Appointment> findByPatientEmail(String patientEmail);

    List<Appointment> findByPatientPhone(String patientPhone);
    
    List<Appointment> findByDoctorId(Long doctorId);
    
    

}
