package com.example.demo.controller;

import lombok.AllArgsConstructor;
import com.example.demo.entity.Appointment;
import com.example.demo.service.AppointmentService;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/appointments")
public class AppointmentController {

    private AppointmentService appointmentService;

    // Get appointments for a patient
    @GetMapping("/patient")
    public List<Appointment> getPatientAppointments(
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String phone) {

        return appointmentService.getAppointmentsByPatient(email, phone);
    }
    
    @PostMapping("/book")
    public ResponseEntity<Boolean> bookAppointment(
            @RequestBody Appointment appointment) {

        boolean isBooked = appointmentService.bookAppointment(appointment);

        return ResponseEntity.ok(isBooked);
    }
    
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<Appointment>> getAppointmentsForDoctor(
            @PathVariable Long doctorId) {

        return ResponseEntity.ok(
                appointmentService.getAppointmentsForDoctor(doctorId)
        );
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAppointment(@PathVariable Long id) {
        appointmentService.deleteAppointment(id);
        return ResponseEntity.ok("Appointment cancelled successfully");
    }



}

