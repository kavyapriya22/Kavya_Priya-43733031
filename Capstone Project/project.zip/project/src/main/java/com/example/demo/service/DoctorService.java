package com.example.demo.service;

import com.example.demo.entity.Doctor;
import java.util.List;

public interface DoctorService {
    Doctor registerDoctor(Doctor doctor);
    List<Doctor> getAllDoctors();
    
    Long loginDoctorAndGetId(String email, String phone, String password);

    
}
