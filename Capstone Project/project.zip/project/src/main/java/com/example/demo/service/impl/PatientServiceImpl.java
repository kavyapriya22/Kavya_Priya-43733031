package com.example.demo.service.impl;

import lombok.AllArgsConstructor;
import com.example.demo.entity.Patient;
import com.example.demo.repository.PatientRepository;
import com.example.demo.service.PatientService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class PatientServiceImpl implements PatientService {

    private PatientRepository patientRepository;

    @Override
    public Patient registerPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    @Override
    public boolean loginPatient(String email, String phone, String password) {

        Optional<Patient> patientOptional;

        if (email != null && !email.isEmpty()) {
            patientOptional = patientRepository.findByEmail(email);
        } else {
            patientOptional = patientRepository.findByPhone(phone);
        }

        if (patientOptional.isPresent()) {
            Patient patient = patientOptional.get();
            return patient.getPassword().equals(password);
        }

        return false;
    }
}
