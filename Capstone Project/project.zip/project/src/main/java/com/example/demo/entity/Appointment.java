package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "appointments")
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Doctor info
    @Column(nullable = false)
    private Long doctorId;

    // Patient info
    @Column
    private Long patientId;

    @Column
    private String patientEmail;

    @Column
    private String patientPhone;

    // Appointment info
    @Column(nullable = false)
    private LocalDate appointmentDate;

    @Column(nullable = false)
    private LocalTime appointmentTime;
    
    @Transient
    private String doctorName;
    
    @Transient
    private String patientName;



}
